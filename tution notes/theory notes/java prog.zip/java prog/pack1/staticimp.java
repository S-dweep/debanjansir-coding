package pack1;
import static java.lang.System.*;
import java.util.*;
import static java.lang.Math.*;
class A
{
public static void main(String args[])
{
int a;
Scanner sc=new Scanner(in);
System.out.println("enter any value");
a=sc.nextInt();
out.println("entered value "+a);
out.println(pow(3,2));
out.println(exp(3));
out.println(max(89,7));
out.println(min(78,9));
}
}
