import java.util.*;
class A
{
public static void main(String ar[])
{
double a,b;
System.out.println("Enter two double values");
Scanner sc=new Scanner(System.in);
a=sc.nextDouble();
b=sc.nextDouble();
System.out.println("result="+(a+b));
}
}