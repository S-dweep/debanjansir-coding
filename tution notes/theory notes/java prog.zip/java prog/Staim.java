import static java.lang.System.*;
class A
{
public static void main(String ar[])
{
out.println("My name is D");
}
}