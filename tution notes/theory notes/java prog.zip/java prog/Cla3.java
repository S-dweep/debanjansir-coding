class Cla3
{
public static void main(String ar[])
      {
          System.out.println(Integer.parseInt(ar[0])+Integer.parseInt(ar[1]));
      }
}
