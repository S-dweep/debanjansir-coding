class A
{

int a;
A()
{
a=7;
}
int b;
void x()
{

System.out.println(b);
}
public static void main(String args[])
{
A y=new A();
y.x();
}
}