import static java.lang.System.*;
import static java.lang.Math.*;
class A
{
public static void main(String args[]) 
{
out.println("Argument"+args[0]);
out.println(pow(6,5));;
out.println(max(6,5));
}
}
